<template>
    <b-container>
        <b-row>
            <b-col cols="2"></b-col>
            <b-col cols="8">
                <b-card class="bg-royalblue">
                    <b-row>
                        <b-col cols="6" class="text-white">
                            <router-link to="/play">
                                <Icon type="ios-arrow-back"
                            /></router-link>
                            Game Record
                        </b-col>
                        <b-col cols="6"></b-col>
                    </b-row>

                    <vk-tabs align="justify" class="mt-5">
                        <vk-tabs-item title="All">
                            <table class="table table-responsive bg-dark tble ">
                                <tr>
                                    <td class="text-yellow">Parity</td>
                                    <td class="text-white">20219483948</td>
                                    <td class="text-success">Finished</td>
                                    <td class="text-danger">-1.00</td>
                                </tr>
                                <tr>
                                    <td class="text-yellow">Parity</td>
                                    <td class="text-white">20219483948</td>
                                    <td class="text-success">Finished</td>
                                    <td class="text-danger">-1.00</td>
                                </tr>
                                <tr>
                                    <td class="text-yellow">Parity</td>
                                    <td class="text-white">20219483948</td>
                                    <td class="text-success">Finished</td>
                                    <td class="text-danger">-1.00</td>
                                </tr>
                                <tr>
                                    <td class="text-yellow">Parity</td>
                                    <td class="text-white">20219483948</td>
                                    <td class="text-success">Finished</td>
                                    <td class="text-danger">-1.00</td>
                                </tr>
                                <tr>
                                    <td class="text-yellow">Parity</td>
                                    <td class="text-white">20219483948</td>
                                    <td class="text-success">Finished</td>
                                    <td class="text-danger">-1.00</td>
                                </tr>
                                <tr>
                                    <td class="text-yellow">Parity</td>
                                    <td class="text-white">20219483948</td>
                                    <td class="text-success">Finished</td>
                                    <td class="text-danger">-1.00</td>
                                </tr>
                                <tr>
                                    <td class="text-yellow">Parity</td>
                                    <td class="text-white">20219483948</td>
                                    <td class="text-success">Finished</td>
                                    <td class="text-danger">-1.00</td>
                                </tr>
                                <tr>
                                    <td class="text-yellow">Parity</td>
                                    <td class="text-white">20219483948</td>
                                    <td class="text-success">Finished</td>
                                    <td class="text-danger">-1.00</td>
                                </tr>
                                <tr>
                                    <td class="text-yellow">Parity</td>
                                    <td class="text-white">20219483948</td>
                                    <td class="text-success">Finished</td>
                                    <td class="text-danger">-1.00</td>
                                </tr>
                                <tr>
                                    <td class="text-yellow">Parity</td>
                                    <td class="text-white">20219483948</td>
                                    <td class="text-success">Finished</td>
                                    <td class="text-danger">-1.00</td>
                                </tr>
                                <tr>
                                    <td class="text-yellow">Parity</td>
                                    <td class="text-white">20219483948</td>
                                    <td class="text-success">Finished</td>
                                    <td class="text-danger">-1.00</td>
                                </tr>
                                <tr>
                                    <td class="text-yellow">Parity</td>
                                    <td class="text-white">20219483948</td>
                                    <td class="text-success">Finished</td>
                                    <td class="text-danger">-1.00</td>
                                </tr>
                            </table>
                        </vk-tabs-item>
                        <vk-tabs-item title="Parity">
                            <table class="table table-responsive bg-dark tble ">
                                <tr>
                                    <td class="text-yellow">Parity</td>
                                    <td class="text-white">20219483948</td>
                                    <td class="text-success">Finished</td>
                                    <td class="text-danger">-1.00</td>
                                </tr>
                                <tr>
                                    <td class="text-yellow">Parity</td>
                                    <td class="text-white">20219483948</td>
                                    <td class="text-success">Finished</td>
                                    <td class="text-danger">-1.00</td>
                                </tr>
                                <tr>
                                    <td class="text-yellow">Parity</td>
                                    <td class="text-white">20219483948</td>
                                    <td class="text-success">Finished</td>
                                    <td class="text-danger">-1.00</td>
                                </tr>
                                <tr>
                                    <td class="text-yellow">Parity</td>
                                    <td class="text-white">20219483948</td>
                                    <td class="text-success">Finished</td>
                                    <td class="text-danger">-1.00</td>
                                </tr>
                                <tr>
                                    <td class="text-yellow">Parity</td>
                                    <td class="text-white">20219483948</td>
                                    <td class="text-success">Finished</td>
                                    <td class="text-danger">-1.00</td>
                                </tr>
                                <tr>
                                    <td class="text-yellow">Parity</td>
                                    <td class="text-white">20219483948</td>
                                    <td class="text-success">Finished</td>
                                    <td class="text-danger">-1.00</td>
                                </tr>
                                <tr>
                                    <td class="text-yellow">Parity</td>
                                    <td class="text-white">20219483948</td>
                                    <td class="text-success">Finished</td>
                                    <td class="text-danger">-1.00</td>
                                </tr>
                                <tr>
                                    <td class="text-yellow">Parity</td>
                                    <td class="text-white">20219483948</td>
                                    <td class="text-success">Finished</td>
                                    <td class="text-danger">-1.00</td>
                                </tr>
                                <tr>
                                    <td class="text-yellow">Parity</td>
                                    <td class="text-white">20219483948</td>
                                    <td class="text-success">Finished</td>
                                    <td class="text-danger">-1.00</td>
                                </tr>
                                <tr>
                                    <td class="text-yellow">Parity</td>
                                    <td class="text-white">20219483948</td>
                                    <td class="text-success">Finished</td>
                                    <td class="text-danger">-1.00</td>
                                </tr>
                                <tr>
                                    <td class="text-yellow">Parity</td>
                                    <td class="text-white">20219483948</td>
                                    <td class="text-success">Finished</td>
                                    <td class="text-danger">-1.00</td>
                                </tr>
                                <tr>
                                    <td class="text-yellow">Parity</td>
                                    <td class="text-white">20219483948</td>
                                    <td class="text-success">Finished</td>
                                    <td class="text-danger">-1.00</td>
                                </tr>
                            </table>
                        </vk-tabs-item>
                    </vk-tabs>
                </b-card>
            </b-col>
            <b-col cols="2"></b-col>
        </b-row>
    </b-container>
</template>

<script>
export default {};
</script>

<style>
.tble > tr > td {
    width: 31%;
}
.tble {
    border: none !important;
    height: 400px;
    overflow: scroll;
}
.tble::-webkit-scrollbar {
    display: none;
}
</style>
