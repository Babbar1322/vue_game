<template>
    <b-container>
        <b-row>
            <b-col cols="2"></b-col>
            <b-col cols="8">
                <b-card class="bg-royalblue">
                    <b-row>
                        <b-col cols="6" class="text-white">
                            
                                <Icon type="ios-arrow-back" />
                               Recharge Record </div>
                        </b-col>
                        <b-col cols="6"></b-col>
                    </b-row>

                    <vk-tabs align="justify" class="mt-5">
                        <vk-tabs-item title="All">
                            <table class="table table-responsive bg-dark tble1 ">
                                <tr>
                                    <td class="text-primary"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">UnPaid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-primary"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">UnPaid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-primary"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">UnPaid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-primary"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">UnPaid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-primary"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">UnPaid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-primary"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">UnPaid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-primary"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">UnPaid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-primary"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">UnPaid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-primary"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">UnPaid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-primary"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">UnPaid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-primary"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">UnPaid</div></td>
                                </tr>
                            </table>
                        </vk-tabs-item>
                        <vk-tabs-item title="Paid">
                            <table class="table table-responsive bg-dark tble1 ">
                                <tr>
                                    <td class="text-primary"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">Paid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-primary"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">Paid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-white"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">Paid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-white"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">UnPaid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-white"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">Paid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-white"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">Paid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-white"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">Paid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-white"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">Paid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-white"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">Paid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-primary"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">Paid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-primary"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">Paid</div></td>
                                </tr>
                            </table>
                        </vk-tabs-item>
                        <vk-tabs-item title="UnPaid">
                            <table class="table table-responsive bg-dark tble1 ">
                                <tr>
                                    <td class="text-primary"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">UnPaid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-primary"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">UnPaid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-primary"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">UnPaid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-primary"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">UnPaid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-primary"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">UnPaid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-primary"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">UnPaid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-primary"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">UnPaid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-primary"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">UnPaid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-primary"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">UnPaid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-primary"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">UnPaid</div></td>
                                </tr>
                                <tr>
                                    <td class="text-primary"><div>Recharge method: UPI</div><div>2021081614434346814</div><div>2021/08/16 12:13:43</div></td>
                                    <td class="text-right"><div class="text-success">300.00</div><div class="text-danger">UnPaid</div></td>
                                </tr>
                            </table>
                            </vk-tabs-item>
                    </vk-tabs>
                </b-card>
            </b-col>
            <b-col cols="2"></b-col>
        </b-row>
    </b-container>
</template>

<script>
export default {};
</script>

<style>
.tble1 > tr>td{
width: 20%;
}
.tble1{
    border: none !important;
    height: 400px;
    overflow: scroll;
}
.tble1::-webkit-scrollbar {
    display: none;
}
</style>
