<template>
    <h1>route not found</h1>
</template>

<script>
export default {};
</script>

<style></style>
