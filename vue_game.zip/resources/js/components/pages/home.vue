<template>
    <h1>home vue</h1>
</template>

<script>
export default {};
</script>

<style></style>
