<script>
import Vue from "vue";
const EventBus = new Vue();
export default EventBus;
</script>
